#!/usr/bin/env python3
"""Oracle report generator: reconcile the corrected snapshot against the
read-only stale baseline and write /app/report.json (see instruction.md)."""

import argparse
import json
import os
import sqlite3


def read_balances(db_path):
    con = sqlite3.connect(db_path)
    bal = {a: int(c) for a, c in con.execute("SELECT account_id, balance_cents FROM accounts")}
    con.close()
    return bal


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--app-dir", default=os.environ.get("APP_DIR", "/app"))
    args = ap.parse_args()
    app = args.app_dir

    new_db = os.path.join(app, "state", "ledger.db")
    stale_db = os.path.join(app, "state", "baseline_stale.db")

    new_bal = read_balances(new_db)
    stale_bal = read_balances(stale_db)

    con = sqlite3.connect(new_db)
    rejected_ids = sorted(e for (e,) in con.execute("SELECT event_id FROM rejected_events"))
    meta = {k: int(v) for k, v in con.execute("SELECT key, value FROM meta")}
    con.close()

    ids = set(new_bal) | set(stale_bal)
    report = {
        "duplicate_events_ignored": meta["duplicates_ignored"],
        "rejected_event_ids": rejected_ids,
        "accounts_with_corrected_balance": sum(
            1 for a in ids if stale_bal.get(a) != new_bal.get(a)
        ),
        "total_absolute_drift_cents": sum(
            abs(new_bal.get(a, 0) - stale_bal.get(a, 0)) for a in ids
        ),
    }

    out = os.path.join(app, "report.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)
    print("wrote %s" % out)


if __name__ == "__main__":
    main()
